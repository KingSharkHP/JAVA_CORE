public class ShiftRight {
    public class ArrayShift {
        public static void shiftRight(int[] arr) {
            if (arr.length <= 1) {
                return;
            }
    
            int lastElement = arr[arr.length - 1];
    
            for (int i = arr.length - 2; i >= 0; i--) {
                arr[i + 1] = arr[i];
            }
    
            arr[0] = lastElement;
        }
    }
    
}
